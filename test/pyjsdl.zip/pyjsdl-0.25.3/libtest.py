#!/usr/bin/env python

#Libtest
#check doc/libtest.txt for information

import sys
sys.dont_write_bytecode = True

from test import libtest

libtest.main()

